from .APItoken import API_TOKEN
# Assessor API request URL
URL = 'https://api.mcassessor.maricopa.gov/'
PAYLOAD={}
HEAD = {
  'AUTHORIZATION': API_TOKEN
}
