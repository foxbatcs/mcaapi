# libraries
import requests
import json
import urllib.parse
