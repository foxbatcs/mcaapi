# Assessor API request URL
URL = 'https://api.mcassessor.maricopa.gov/'

API_TOKEN = 'YOUR_API_TOKEN'
PAYLOAD={}
HEAD = {
  'AUTHORIZATION': API_TOKEN,
  'Cookie': 'pecan=261489418.47873.0000'
}
